<div class="box box-solid bg-dark">
  <div class="box-header with-border">
    <h3 class="box-title"><span class="khmer_font">ទម្រង់ចុះឈ្មោះឧស្សាហកម្មថ្មី &#47; </span>New Industry Form</h3>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
    <div class="row">
      <div class="col-3">
      </div>
      <div class="col-6">
          <div class="form-group row">
            <label for="example-text-input" class="col-sm-2 col-form-label text-right"><span class="khmer_font">ឈ្មោះឧស្សាហកម្ម<br/></span>Industry Name<span class="text-danger">&#9734;</span></label>
            <div class="col-sm-10">
              <input class="form-control" type="text" placeholder="Industry Name" id="example-text-input">
            </div>
          </div>
          <div class="form-group row">
              <label for="example-text-input" class="col-sm-2 col-form-label text-right"><span class="khmer_font">ពិពណ៌នាអំពីឧស្សាហកម្ម<br/></span>Industry Description</label>
              <div class="col-sm-10">
                  <textarea name="textarea" id="textarea" class="form-control" placeholder="Please add some description."></textarea>
              </div>
          </div>
      </div>
      <div class="col-3">
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  <div class="text-xs-right">
      <button type="submit" class="btn btn-info">Submit New Industry</button>
  </div>
  </div>
  <!-- /.box-body -->
</div>