export * from './src/echarts';

import './src/component/dataset';

import './src/chart/line';
import './src/chart/bar';
import './src/chart/pie';
import './src/component/gridSimple';