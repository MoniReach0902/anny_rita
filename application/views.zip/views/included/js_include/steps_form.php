<!-- steps  -->
<script src="../../assets/vendor_components/jquery-steps-master/build/jquery.steps.js"></script>

<!-- validate  -->
<script src="../../assets/vendor_components/jquery-validation-1.17.0/dist/jquery.validate.min.js"></script>

<!-- Sweet-Alert  -->
<script src="../../assets/vendor_components/sweetalert/sweetalert.min.js"></script>

<!-- wizard  -->
<script src="js/pages/steps.js"></script>