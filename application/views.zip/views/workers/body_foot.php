<!--  <div class="row">
      <div class="col-md-6">
          <div class="form-group">
          <button type="submit" class="btn btn-success">Submit New Record</button>
          </div>
      </div>
      <div class="col-md-6">
          
      </div>
  </div>-->
</form>
</div>
</div>
  <!-- /.box-body -->
</div>
</section>
</div>
<!-- /.content-wrapper -->