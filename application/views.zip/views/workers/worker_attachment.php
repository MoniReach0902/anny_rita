<!-- Step 6 -->
<h6><span class="khmer_font">បញ្ចូលឯកសារពាក់ព័ន្ធ<br/></span>File Attachement</h6>
<section class="bg-hexagons-dark">
  <div class="row">
	  <div class="col-md-3">
	  </div>
	  <div class="col-md-6">
        <!--File attachment-->
        <?php //include_once('page/attachment.php') ?>
        <!--End of File attachment-->
		<div class="form-group row mb-0">
        <div class="col-12">
            <button type="submit" class="btn btn-success">
                <i class="fa fa-plus mr-5"></i> Add more File
            </button>
        </div>
  		</div>
	  </div>
	  <div class="col-md-3">
	  </div>
  </div>
</section>